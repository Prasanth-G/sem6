
#INFIX TO POSTFIX CONVERSION

class Stack:
     def __init__(self):
         self.items = []

     def isEmpty(self):
         return self.items == []

     def push(self, item):
         self.items.append(item)

     def pop(self):
         return self.items.pop()

     def peek(self):
         return self.items[len(self.items)-1]

     def size(self):
         return len(self.items)

def priority(operator):
    if operator == '(':
        return 0
    elif operator == '+' or operator == '-':
        return 1
    elif operator == '*' or operator == '/' or operator == '%':
        return 2
    elif operator == '^':
        return 3

def InfixToPostfix(infixExpr):
    postfixExpr = ''
    S = Stack()
    for ch in infixExpr:
        if ch == ' ':
            continue
        if ch.isalnum():
            postfixExpr += ch
        else:
            if ch == ')':
                while not S.isEmpty() and S.peek() != '(':
                    postfixExpr += S.pop()
                S.pop()
            elif ch == '(':
                S.push(ch)
            else:                 
                while not S.isEmpty() and priority(S.peek()) >= priority(ch):
                        postfixExpr += S.pop()
                S.push(ch)
    while not S.isEmpty():
        postfixExpr += S.pop()
    return postfixExpr

if __name__ == "__main__":
    infixExpr = raw_input("Enter the infix expression:")
    postfixExpr = InfixToPostfix(infixExpr)
    print "The postfix is:", postfixExpr
    
