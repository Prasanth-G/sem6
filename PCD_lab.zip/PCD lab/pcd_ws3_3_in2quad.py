
#INFIX TO QUADRUPLES

class Stack:
     def __init__(self):
         self.items = []

     def isEmpty(self):
         return self.items == []

     def push(self, item):
         self.items.append(item)

     def pop(self):
         return self.items.pop()

     def peek(self):
         return self.items[len(self.items)-1]

     def size(self):
         return len(self.items)

def priority(operator):
    if operator == '(':
        return 0
    elif operator == '+' or operator == '-':
        return 1
    elif operator == '*' or operator == '/' or operator == '%':
        return 2
    elif operator == '^':
        return 3

def InfixToPostfix(infixExpr):
    postfixExpr = ''
    S = Stack()
    for ch in infixExpr:
        if ch == ' ':
            continue
        if ch.isalnum():
            postfixExpr += ch + ' '
        else:
            if ch == ')':
                while not S.isEmpty() and S.peek() != '(':
                    postfixExpr += S.pop() + ' '
                S.pop()
            elif ch == '(':
                S.push(ch)
            else:                 
                while not S.isEmpty() and priority(S.peek()) >= priority(ch):
                    postfixExpr += S.pop() + ' '
                S.push(ch)
    while not S.isEmpty():
        postfixExpr += S.pop() + ' '
    return postfixExpr

operators = ['+', '-', '*', '/', '^']

def PostfixToQuadruples(postfixExpr):
    postfixExpr = postfixExpr.rstrip().split(' ')
    print postfixExpr 
    quadruples = []
    k = 0
    while len(postfixExpr) > 1:
        for i in range(len(postfixExpr)):
            if postfixExpr[i] in operators:
                break
        quadruples.append([str(k), postfixExpr[i-2], postfixExpr[i-1], postfixExpr[i]])
        postfixExpr = postfixExpr[:(i-2)] + [str(k)] + postfixExpr[(i+1):]
        #print postfixExpr
        k += 1
    return quadruples

if __name__ == "__main__":
    infixExpr = raw_input("Enter the infix expression:")
    postfixExpr = InfixToPostfix(infixExpr)
    quadruples = PostfixToQuadruples(postfixExpr)
    print "The quadruple representation is:", quadruples
