
#POSTFIX TO INDIRECT TRIPLES FOLLOWED BY, COMMON SUB EXPRESSION ELIMINATION 

operators = ['+', '-', '*', '/', '^']

def PostfixToIndirectTriples(postfixExpr):
    postfixExpr = postfixExpr.rstrip().split(' ')
    print postfixExpr 
    triples = []
    k = 0
    while len(postfixExpr) > 1:
        for i in range(len(postfixExpr)):
            if postfixExpr[i] in operators:
                break
        triples.append([postfixExpr[i-2], postfixExpr[i-1], postfixExpr[i]])
        postfixExpr = postfixExpr[:(i-2)] + [str(k)] + postfixExpr[(i+1):]
        #print postfixExpr
        k += 1
    return triples

def CommonSubexpressionElimination(triples):
    eliminate = dict()
    #Detecting the possible replacements and storing in the eliminate dictionary
    for i in range(len(triples)):
        print ' '.join(triples[i])
        for j in range(0, i):
            currStmt = ' '.join(triples[i])
            prevStmt = ' '.join(triples[j])
            if currStmt == prevStmt:
                eliminate[chr(i + 48)] = chr(j + 48)
    print eliminate
    #Replacing the occurrences of i by j if {i:j} is in eliminate
    for i in range(len(triples)):
        if triples[i][0] in eliminate.keys():
            triples[i][0] = eliminate.get(triples[i][0])
        if triples[i][1] in eliminate.keys():
            triples[i][1] = eliminate.get(triples[i][1])
    print triples
    #Removing unused statements
    newtriples = []
    for i in range(len(triples)):
        if chr(i + 48) in eliminate.keys():
            continue
        newtriples.append(triples[i])
    return newtriples

if __name__ == "__main__":
    postfixExpr = raw_input("Enter the postfix expression(space separated):")
    triples = PostfixToIndirectTriples(postfixExpr)
    print "The indirect triples representation is:", triples
    triples = CommonSubexpressionElimination(triples)
    print "After common subexpression elimination:", triples
