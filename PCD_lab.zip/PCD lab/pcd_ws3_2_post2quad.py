
#POSTFIX TO QUADRUPLES

operators = ['+', '-', '*', '/', '^']

def PostfixToQuadruples(postfixExpr):
    postfixExpr = postfixExpr.split(' ')
    print postfixExpr 
    quadruples = []
    k = 0
    while len(postfixExpr) > 1:
        for i in range(len(postfixExpr)):
            if postfixExpr[i] in operators:
                break
        quadruples.append([str(k), postfixExpr[i-2], postfixExpr[i-1], postfixExpr[i]])
        postfixExpr = postfixExpr[:(i-2)] + [str(k)] + postfixExpr[(i+1):]
        print postfixExpr
        k += 1
    return quadruples

if __name__ == "__main__":
    postfixExpr = raw_input("Enter the postfix expression(space delimited):")
    quadruples = PostfixToQuadruples(postfixExpr)
    print "The quadruple representation is:", quadruples
